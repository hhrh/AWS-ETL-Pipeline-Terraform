import json
import boto3
import requests
import datetime
import os
from botocore.exceptions import BotoCoreError, ClientError
from requests.exceptions import RequestException
from json.decoder import JSONDecodeError

# create an S3 client, this is to call "put_object()" to upload files to S3
s3 = boto3.client("s3")

S3_BUCKET = os.environ["S3_BUCKET"]
STOCK_SYMBOL = os.environ.get("STOCK_SYMBOL", "AAPL")
ALPHAVANTAGE_API_KEY = os.environ["ALPHAVANTAGE_API_KEY"]

def lambda_handler(_event, _context):
    """
    entry point. AWS Lambda looks for this function.
    "event" and "context" are required params (even if unused (_underscored))
    """

    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H-%M-%S")  # ex: 'AAPL_2025-06-30T12-14-28.json'

    url = (
        f"https://www.alphavantage.co/query?"
        f"function=TIME_SERIES_INTRADAY&symbol={STOCK_SYMBOL}"
        f"&interval=5min&apikey={ALPHAVANTAGE_API_KEY}"
    )
    file_name = f"{STOCK_SYMBOL}_{now}.json" # unique file name for tracking

    try:
        # Logic: request, parse, upload to S3
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        s3.put_object(
            Bucket=S3_BUCKET, # bucket to write to
            Key=f"raw/{file_name}", # path to file in bucket to write to
            Body=json.dumps(data), # body must be string or bytes (serialize w/ json.dumps())
            ContentType="application/json" #MIME type
        )

        # Lambda MUST return a dict with statusCode and body
        return {
            "statusCode": 200,
            "body": json.dumps({"message": f"Data saved to {file_name}"})
        }

    # Error handling
    except (RequestException, JSONDecodeError, BotoCoreError, ClientError) as expected_err:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Handled error: {str(expected_err)}"})
        }

    except Exception as unknown_err:  # pylint: disable=broad-exception-caught
        print(f"[Unhandled Exception] {type(unknown_err).__name__}: {unknown_err}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Unexpected error occurred."})
        }

# for local testing (not on lambda)
if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    with open("lambda_ingest/test_event.json", encoding="utf-8") as f:
        event = json.load(f)
    print(lambda_handler(event, None))
